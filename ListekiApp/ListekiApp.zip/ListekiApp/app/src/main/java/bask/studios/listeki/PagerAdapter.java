package bask.studios.listeki;


import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class PagerAdapter extends FragmentPagerAdapter {
    private int tabsNumber;

    public PagerAdapter(FragmentManager fm,int tabs) {
        super(fm);
        this.tabsNumber=tabs;
    }


    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                return new First();
            case 1:
                return new second();
            case 2:
                return new third();
                default: return null;
        }
    }

    @Override
    public int getCount() {
        return 0;
    }
}
